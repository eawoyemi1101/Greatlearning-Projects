const square = function(num) {
    return num * num;
};

// Example usage
const input = 2;
const output = square(input);
console.log(output); // Output = 4

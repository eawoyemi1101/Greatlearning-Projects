document.addEventListener('DOMContentLoaded', () => {
    displayClubs(footballClubs);
});

function handleClubClick(cardElement) {
    const clubName = cardElement.getAttribute('data-club-name');
    const club = footballClubs.find(club => club.name === clubName);
    displayClubDetails(club);
}

function displayClubDetails(club) {
    document.getElementById('club-list').classList.remove('active');
    document.getElementById('club-details').classList.add('active');
    
    document.getElementById('club-title').textContent = club.name;
    document.getElementById('club-logo').src = club.logo;
    document.getElementById('club-league').textContent = `League: ${club.league}`;
    document.getElementById('club-city').textContent = `City: ${club.city}`;
    document.getElementById('club-stadium').textContent = `Stadium: ${club.stadium}`;
    document.getElementById('club-description').textContent = `Description: ${club.description}`;
}

function viewPlayers() {
    const clubName = document.getElementById('club-title').textContent;
    viewClubPlayers(clubName);
}

function viewClubPlayers(clubName) {
    const club = footballClubs.find(club => club.name === clubName);
    const playersList = document.getElementById('players-list');
    playersList.innerHTML = ''; // Clear previous player details

    club.players.forEach(player => {
        const li = document.createElement('li');
        li.textContent = `Name: ${player.name}, Position: ${player.position}, Goals: ${player.goals}, Assists: ${player.assists}`;
        playersList.appendChild(li);
    });

    document.getElementById('club-details').classList.remove('active');
    document.getElementById('player-details').classList.add('active');
    document.getElementById('club-title-players').textContent = club.name;
}

function goBack() {
    document.getElementById('club-details').classList.remove('active');
    document.getElementById('club-list').classList.add('active');
}

function goBackToClub() {
    document.getElementById('player-details').classList.remove('active');
    document.getElementById('club-details').classList.add('active');
}

function handleSearchInput() {
    const searchValue = document.getElementById('search-box').value.toLowerCase();
    const filteredClubs = footballClubs.filter(club => 
        club.name.toLowerCase().includes(searchValue) ||
        club.league.toLowerCase().includes(searchValue) ||
        club.city.toLowerCase().includes(searchValue)
    );
    displayClubs(filteredClubs);
}

function displayClubs(filteredClubs) {
    const clubList = document.getElementById('club-list');
    clubList.innerHTML = ''; // Clear previous club list

    filteredClubs.forEach(club => {
        const div = document.createElement('div');
        div.className = 'club-card active';
        div.setAttribute('data-club-name', club.name);
        div.onclick = () => handleClubClick(div);
        div.innerHTML = `<h3>${club.name}</h3>`;
        clubList.appendChild(div);
    });

    if (!clubList.classList.contains('active')) {
        clubList.classList.add('active');
    }
}

const projects = [
    {
      title: 'To-Do List App',
      description: 'A simple app to keep track of tasks and manage your daily to-dos.',
      image: ''
    },
    {
      title: 'Calculator App',
      description: 'An easy-to-use calculator for basic arithmetic calculations.',
      image: ''
    },
    {
      title: 'Weather App',
      description: 'Get real-time weather updates for your location or any specified location.',
      image: ''
    },
    {
      title: 'Timer App',
      description: 'Set timers for various tasks or activities with customizable options.',
      image: ''
    },
    {
      title: 'Chat App',
      description: 'Connect with friends and colleagues through instant messaging and group chats.',
      image: ''
    }
  ];
(function(personName) {
    console.log("Hello " + personName + ", Welcome to Great Learning!");
})("Harry");

const videos = [
    { title: "Video 1", url: "videos/video1.mp4" },
    { title: "Video 2", url: "videos/video2.mp4" },
    { title: "Video 3", url: "videos/video3.mp4" },
    { title: "Video 4", url: "videos/video4.mp4" }
];

originalList = videos;

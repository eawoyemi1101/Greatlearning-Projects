// Assume projects array is defined elsewhere and accessible globally

// Save new project details
function saveNewProject() {
    // Fetch form input values using DOM manipulation
    const projectNameInput = document.getElementById('projectName');
    const projectDescriptionInput = document.getElementById('projectDescription');
  
    // Check if elements exist
    if (!projectNameInput || !projectDescriptionInput) {
      console.error('Form elements not found.');
      return;
    }
  
    const projectName = projectNameInput.value.trim();
    const projectDescription = projectDescriptionInput.value.trim();
  
    // Checking if project name and description are not empty
    if (projectName === '' || projectDescription === '') {
      alert('Please enter both project name and description.');
      return;
    }
  
    // Create a new project object
    const newProject = {
      title: projectName,
      description: projectDescription,
      image: '' // Placeholder image URL
    };
  
    // Add the new project to the projects array
    projects.push(newProject);
  
    // Clear form inputs
    projectNameInput.value = '';
    projectDescriptionInput.value = '';
  
    // Reload projects
    loadProjects();
  }
  
  // Function to load projects
  function loadProjects() {
    const projectsContainer = document.getElementById('projectsContainer');
  
    // Check if container exists
    if (!projectsContainer) {
      console.error('Projects container not found.');
      return;
    }
  
    // Clear container content
    projectsContainer.innerHTML = '';
  
    // Loop through projects array and create project cards
    for (let i = 0; i < projects.length; i++) {
      const project = projects[i];
      const projectCard = document.createElement('div');
      projectCard.classList.add('project-card');
      projectCard.innerHTML = `
        <h3>${project.title}</h3>
        <p>${project.description}</p>
        <img src="${project.image}" alt="${project.title}" class="project-image">
      `;
      projectsContainer.appendChild(projectCard);
    }
  }
  
  // Call the loadProjects function when the page loads
  window.onload = loadProjects;
  
  // Test if js is properly connected
  console.log('Hello from script.js!');
  
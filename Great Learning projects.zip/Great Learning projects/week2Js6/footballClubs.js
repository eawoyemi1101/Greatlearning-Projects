const footballClubs = [
    {
        name: "Club Name 1",
        logo: "logo1.png",
        league: "League 1",
        city: "City 1",
        stadium: "Stadium 1",
        description: "Description 1",
        players: [
            { name: "Player 1", position: "Forward", goals: 10, assists: 5 },
            { name: "Player 2", position: "Midfielder", goals: 5, assists: 10 }
        ]
    },
    {
        name: "Club Name 2",
        logo: "logo2.png",
        league: "League 2",
        city: "City 2",
        stadium: "Stadium 2",
        description: "Description 2",
        players: [
            { name: "Player 3", position: "Defender", goals: 2, assists: 1 },
            { name: "Player 4", position: "Goalkeeper", goals: 0, assists: 0 }
        ]
    }
    // Add more clubs as needed
];
